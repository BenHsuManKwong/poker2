import java.util.*;
import java.io.*;

//Game------------------------------------------------------
class Game implements Serializable{

	private Deck deck;
	private Tableau [] tabs;
	private FreeCell [] cells;
	private HomeCell [] home;

	private char srcType = ' ';
	private char desType = ' ';
	private int srcIndex;
	private int desIndex;

	public Game(){
		deck = new Deck();
		tabs = new Tableau[8];
		for(int i=0;i<tabs.length;i++){tabs[i] = new Tableau();}
		cells = new FreeCell[8];
		for(int i=0;i<cells.length;i++){cells[i] = new FreeCell();}
		home = new HomeCell[4];
		for(int i=0;i<home.length;i++){home[i] = new HomeCell();}
	}

	public Game(int seed){
		deck = new Deck(seed);
		tabs = new Tableau[8];
		for(int i=0;i<tabs.length;i++){tabs[i] = new Tableau();}
		cells = new FreeCell[8];
		for(int i=0;i<cells.length;i++){cells[i] = new FreeCell();}
		home = new HomeCell[4];
		for(int i=0;i<home.length;i++){home[i] = new HomeCell();}
	}

	public Tableau getTableau(int i){
		return tabs[i];
	}

	public FreeCell getFreeCell(int i){
		return cells[i];
	}

	public HomeCell getHomeCell(int i){
		return home[i];
	}

	public void deal(){
		deck.shuffle();

		int d =(deck.count()-1);
		for(int i=0; i<4; i++){
			cells[i].put(deck.take());
		}

		for(int i=0; i<tabs.length;i++){
			for(int j=0;j<6;j++){
				tabs[i].init(deck.take());
			}
		}
	}

	public void display(){
		System.out.println("");
		System.out.println("============================");
		System.out.println("");

		for(int i=0; i<tabs.length;i++){
			System.out.println("Tableau "+(i+1)+tabs[i]);
		}
		System.out.println("");

		System.out.print("FREECELL: [");
		for(int i=0;i<cells.length-1;i++){
			System.out.print(cells[i]+", ");
		}
		System.out.println(cells[cells.length-1]+"]");
		System.out.println("");

		System.out.print("HOMECELL: [");
		for(int i=0;i<home.length-1;i++){
			System.out.print(home[i]+", ");
		}
		System.out.println(home[home.length-1]+"]");

	}

	public boolean isWin(){
//		if(home[0].count==13 && home[1].count==13 && home[2].count==13 && home[3].count==13){
//			return true;
//		}
//		else return false;
		if(home[0].isFull()&& home[1].isFull() && home[2].isFull()&& home[3].isFull()){
			return true;
		}
		else return false;
	}

	public boolean setSrcMove(String s){

		switch(s.charAt(0)){
			case('T'):case('t'):
				if(s.length()>1){
					srcType = 'T';break;
				}
				else{
					System.out.println("Please reply as (L), (S), (Q), (T#) or (F#).");return false;
				}
			case('F'):case('f'):
				if(s.length()>1){
					srcType = 'F';break;
				}
				else{
					System.out.println("Please reply as (L), (S), (Q), (T#) or (F#).");return false;
				}
			default:
				srcType = ' ';srcIndex = -1;System.out.println("Please reply as (L), (S), (Q), (T#) or (F#).");
				return false;
		}

		char a = s.charAt(1);
		if(Character.getNumericValue(a)>0 && Character.getNumericValue(a)<9){
			srcIndex = (Character.getNumericValue(a)-1);
				if(srcType == 'T' && tabs[srcIndex].isEmpty()==true){
					System.out.println("Invalid move."+srcType+(srcIndex+1) +" is empty.");
					return false;
				}
				if(srcType == 'F' && cells[srcIndex].isEmpty()==true){
					System.out.println("Invalid move."+srcType+(srcIndex+1) +" is empty.");
					return false;
				}
			return true;
		}
		else{System.out.println("Please enter number from 1 to 8.");srcIndex = -1;return false;}




	}

	public boolean setDesMove(String s){
		switch(s.charAt(0)){
			case('T'):case('t'):
				if(s.length()>1){
					desType = 'T';
					break;
				}
				else{
					System.out.println("Please reply as (L), (S), (Q), (T#) or (F#).");
					return false;
				}
			case('F'):case('f'):desType = 'F';return true;
			case('H'):case('h'):desType = 'H';return true;
			default: desType=' ';desIndex=-1;System.out.println("Please reply as (L), (S), (Q), (T#) or (F#).");return false;
		}
		char a = s.charAt(1);
		if(Character.getNumericValue(a)>0 && Character.getNumericValue(a)<9){
			desIndex = (Character.getNumericValue(a)-1);
			return true;
		}
		else{desIndex=-1;System.out.println("Please enter number from 1 to 8.");return false;}
	}

	public boolean move(){


		if(srcType!=' '&& desType!=' '){
			if(srcType == 'T' && tabs[srcIndex].isEmpty()==false){
				switch(desType){
				case('T'):
					if(tabs[desIndex].isFull() == false){
						if(tabs[desIndex].put(tabs[srcIndex].top()) == true){
							tabs[desIndex].put(tabs[srcIndex].take());
							System.out.println(tabs[desIndex].top()+" moved.");
							return true;
						}
					}
					System.out.println("Invalid move: "+tabs[srcIndex].top()+" to "+desType+(desIndex+1));
					System.out.println("Please try another move.");
					return false;
				case('F'):

					for(int i=0; i<cells.length;i++){
						if(cells[i].isFull()==true){
							continue;
						}
						else{
							cells[i].put(tabs[srcIndex].take());
							System.out.println(cells[i].top()+" moved.");
							return true;
						}
					}
					System.out.println("Freecells are full.");
					return false;
				case('H'):
					if(tabs[srcIndex].top().getRank() == 1){
						for(int i=0; i<home.length;i++){
							if(home[i].isFull()==true || home[i].isEmpty() == false){
								continue;
							}
							if(home[i].put(tabs[srcIndex].top())==false){
								System.out.println("The first space of each Homecell is full.");
								return false;
							}
							else{
								home[i].put(tabs[srcIndex].take());System.out.println(home[i].top()+" moved.");
								return true;
							}
						}
					System.out.println("Invalid move: "+tabs[srcIndex].top()+" to homecell");
					System.out.println("Please try another move.");
					return false;
					}
					if(tabs[srcIndex].top().getRank() !=1){
						for(int i=0;i<home.length;i++){
							if(home[i].isEmpty()==true){
					System.out.println("Invalid move: "+tabs[srcIndex].top()+" to "+desType+(desIndex+1));
					System.out.println("Please try another move.");
								return false;}
							if(home[i].top().getSuit()==tabs[srcIndex].top().getSuit() && (home[i].top().getRank()+1)==tabs[srcIndex].top().getRank()){
								home[i].put(tabs[srcIndex].take());System.out.println(home[i].top()+" moved.");
								return true;
							}
						}
					System.out.println("Invalid move: "+tabs[srcIndex].top()+" to "+desType+(desIndex+1));
					System.out.println("Please try another move.");
					return false;
					}
				}
			}
			if(srcType == 'F' && cells[srcIndex].isEmpty()==false){
				switch(desType){
				case('T'):
					if(tabs[desIndex].isFull()==false){
						if(tabs[desIndex].put(cells[srcIndex].top())==true){
							tabs[desIndex].put(cells[srcIndex].take());
							System.out.println(tabs[desIndex].top()+" moved.");
							return true;
						}
					}
					System.out.println("Invalid move: "+cells[srcIndex].top()+" to "+desType+(desIndex+1));
					System.out.println("Please try another move.");
					return false;
				case('H'):
					if(cells[srcIndex].top().getRank() == 1 ){
						for(int i=0; i<home.length;i++){
							if(home[i].isFull()==true || home[i].isEmpty() == false){
								continue;
							}
							if(home[i].put(cells[srcIndex].top())==false){
								System.out.println("The first space of each Homecell is full.");
								return false;}
							else{home[i].put(cells[srcIndex].take());System.out.println(home[i].top()+" moved.");return true;}
						}
					return false;
					}
					if(cells[srcIndex].top().getRank() !=1){
						for(int i=0;i<home.length;i++){
							if(home[i].isEmpty()==true){return false;}
							if(home[i].top().getSuit()==cells[srcIndex].top().getSuit() && (home[i].top().getRank()+1)==cells[srcIndex].top().getRank()){
								home[i].put(cells[srcIndex].take());System.out.println(home[i].top()+" moved.");
								return true;
							}
						}
					System.out.println("Invalid move: "+tabs[srcIndex].top()+" to "+desType+(desIndex+1));
					System.out.println("Please try another move.");
					return false;
					}
				}
			}
		}
		return false;
	}

	public void loadGame(){

		try{
			ObjectInputStream load = new ObjectInputStream(new FileInputStream(new File("save.dat")));
			Game g = (Game)load.readObject();
			for(int i=0;i<8;i++){
				tabs[i]=g.getTableau(i);
				cells[i]=g.getFreeCell(i);
				if(i<4){home[i] = g.getHomeCell(i);}
			}
			System.out.println("Load Success.");
			load.close();
		}
		catch(FileNotFoundException e){
			System.out.println("File has not found.");
					}
		catch(ClassNotFoundException e){
			System.out.println("Class has not found.");
		}
		catch(IOException e){
			System.out.println("Error : "+e);
			System.out.println("Load Unsuccess.");
		}



	}
	public void saveGame(){
		try{
			File outFile = new File("save.dat");
			FileOutputStream outFileStream = new FileOutputStream(outFile);
			ObjectOutputStream outObjectStream = new ObjectOutputStream(outFileStream);

			outObjectStream.writeObject(this);
			System.out.println("Save Success.");
			outObjectStream.close();
		}
		catch(IOException  ioe){
			ioe.printStackTrace();
			System.out.println("Save Unsuccess.");
		}

	}
}

