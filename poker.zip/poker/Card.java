
import java.io.*;


class Card implements Serializable{
	private int rank;
	private int suit;

	public static final int HEART = 3;
	public static final int CLUB = 4;
	public static final int DIAMOND = 5;
	public static final int SPADE = 6;

	public Card(int suit,int rank) throws InvalidCardException{

		try{
			if(rank<1 || rank>13){
				throw new InvalidCardException();
			}
			else{
			this.rank = rank;
			}
			if(suit<3 || suit>6){
				throw new InvalidCardException();
			}
			else{
			this.suit = suit;
			}
		}
		catch(InvalidCardException e){
			System.out.println(e);
		}

	}

	public int getRank(){return rank;}
	public int getSuit(){return suit;}

	@Override
	public String toString(){

		if(rank == 1){return ""+(char)suit + "A";}
		else if(rank == 10){return ""+(char)suit + "T";}
		else if(rank == 11){return ""+(char)suit + "J";}
		else if(rank == 12){return ""+(char)suit + "Q";}
		else if(rank == 13){return ""+(char)suit + "K";}
		else{return ""+(char)suit + rank;}
	}


}

