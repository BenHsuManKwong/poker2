
class Tableau extends Pile{

	public Tableau(){
		super(18);
	}

	public boolean put(Card c){
		if(isEmpty() == true){
			if(c.getRank() == 13){
				return super.put(c);
			}
			else{
				return false;
			}
		}
		else if(isNextCard(isSameSuit(top().getSuit(),c.getSuit()),isNextRank(top().getRank(),c.getRank()))){
			return super.put(c);
			}
		return false;
	}

	public boolean init(Card intc){
		super.put(intc);
		return false;
	}

	private boolean isSameSuit(int srcSuit,int desSuit){
		return srcSuit == desSuit;
	}

	private boolean isNextRank(int srcRank, int desRank){
		return (srcRank-desRank) == 1;
	}

	private boolean isNextCard(boolean isSameSuit,boolean isNextRank){
		return isSameSuit&&isNextRank;
	}



}
