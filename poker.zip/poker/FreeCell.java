
class FreeCell extends Pile{

	public FreeCell(){
		super(1);
	}
}


