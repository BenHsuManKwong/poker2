import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class GameGUI extends JFrame implements ActionListener {
	Board b;
	Game g;
	JButton newGame, loadGame, saveGame, quitGame;

	public GameGUI() {
		super("Eight Off Solitaire");
		g = new Game();
		b = new Board(g);
		add(b, BorderLayout.CENTER);

		newGame = new JButton("New Game");
		loadGame = new JButton("Load Game");
		saveGame = new JButton("Save Game");
		quitGame = new JButton("Quit Game");
		JPanel p = new JPanel(new GridLayout(1,4));
		p.add(newGame);
		p.add(loadGame);
		p.add(saveGame);
		p.add(quitGame);
		add(p, BorderLayout.NORTH);
		newGame.addActionListener(this);
		loadGame.addActionListener(this);
		saveGame.addActionListener(this);
		quitGame.addActionListener(this);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		pack();
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==quitGame) {
			System.exit(0);
		} else if (e.getSource()==newGame) {
			g = new Game();
			g.deal();
			b.init(g);		// call this method after your load or create a new game.
			repaint();
		}else if(e.getSource()==saveGame){
			g.saveGame();
		}else if(e.getSource()==loadGame){
			g.loadGame();
			b.init(g);
			repaint();
		}
	}

	public static void main (String args[]) {
		GameGUI app = new GameGUI();
	}
}