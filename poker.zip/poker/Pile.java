
import java.io.*;

class Pile implements Serializable{

	protected Card cards[];
	protected int size;
	protected int count;

	public Pile(int size){
		this.size = size;
		cards = new Card[size];
	}

	public boolean isEmpty(){
		return count == 0;
	}

	public boolean isFull(){
		return count == size;
	}

	public int count(){
		return count;
	}

	public Card take(){
		if(!isEmpty()){
		count = count-1;
		return cards[count];
		}
		return null;
	}

	public Card top(){
		if(count>0){
			return cards[count-1];
		}
		return null;
	}

	public boolean put(Card c){
		if(!isFull()){
		cards[count] = c;
			count = count+1;
			return true;
		}
		else{
			return false;
		}
	}

	public String toString(){

		String output = "";
		for(int i=0;i<count;i++){
			if(cards[i]!=null){
				output += (cards[i] + " ");
			}
		}
		return "[ " + output+"]";

	}

	public Card[] getCards(){
		return cards;
	}

}
