
class HomeCell extends Pile{

	public HomeCell(){
		super(13);
	}

	public boolean put(Card c){
		if(isEmpty() == true){
			if(c.getRank() == 1){
				return super.put(c);
			}
			else{return false;}
		}
		if(isNextCard(isSameSuit(top().getSuit(),c.getSuit()), isNextRank(top().getRank(),c.getRank()))){
			return super.put(c);
		}
		return false;

	}

	public String toString(){
		if(isEmpty() == true){
			return "[ ]";
		}
		else return "[ "+super.top()+" ]";
	}

	public boolean isFull(){
		if(count==13){
			return true;
		}
		else{
			return false;
		}
	}


	private boolean isSameSuit(int srcSuit,int desSuit){
			return srcSuit == desSuit;
	}

	private boolean isNextRank(int srcRank, int desRank){
		return (srcRank+1) == desRank;
	}

	private boolean isNextCard(boolean isSameSuit,boolean isNextRank){
		return isSameSuit&&isNextRank;
	}



}
