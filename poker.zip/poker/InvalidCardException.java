


class InvalidCardException extends RuntimeException{

	public InvalidCardException(){
		super("Invalid rank and/or suit for the card.");
	}
}
