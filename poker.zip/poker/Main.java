import java.util.*;
import java.io.*;

class Main{
	public static void main(String[]args){

		Game g =new Game();
		g.deal();
		g.display();
		while(g.isWin() == false){

			Scanner s = new Scanner(System.in);
			String a = " ";

			System.out.println("");
			System.out.println("(L)oad, (S)ave,(Q)uit or");
			System.out.print("Move from (T)ableau op (F)reecell and number of cell (e.g. T3, F4 and etc.): ");
			a = s.nextLine();

			if(a.length() != 0){
			if(a.charAt(0) == 'q' || a.charAt(0) == 'Q'){
				System.out.println("Goood Bye.");
				System.exit(0);
			}
			else if(a.charAt(0) == 's' || a.charAt(0) == 'S'){
				g.saveGame();
			}
			else if(a.charAt(0) == 'l' || a.charAt(0) == 'L'){
				g.loadGame();
			}
				boolean q = g.setSrcMove(a);
					if(q == true){
						System.out.print("Move "+ a +" to (H)omecell,(F)reecell or (T)ableau with number(e.g.H,F,T3 and etc.): " );
						a = s.nextLine();
						if(a.length() != 0){
							g.setDesMove(a);
						}
						else{
							g.setDesMove("no");
							System.out.println("please enter parameters.");
						}
					}
				g.move();
			}
			else{System.out.println("please enter parameters.");}
			g.display();
		}
		System.out.print("Congratulation!You win!");
	}
}




































